from aiogram import Router, types, F
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.fsm.context import FSMContext
from handlers.language import user_lang
from data import first_course, second_course, grill, salads, bakery, drinks
from handlers.state import DishState

router = Router()

category_data = {
    "first_course": first_course.dishes,
    "second_course": second_course.dishes,
    "grill": grill.dishes,
    "salads": salads.salads,
    "bakery": bakery.dishes,
    "drinks": drinks.drinks
}

category_map = {
    "1": "first_course",
    "2": "second_course",
    "3": "grill",
    "4": "salads",
    "5": "drinks",
    "6": "bakery"
}

@router.callback_query(F.data.startswith("category_"))
async def show_dishes(callback: types.CallbackQuery, state: FSMContext):
    category_key = callback.data.replace("category_", "")
    lang = user_lang.get(callback.from_user.id, "ru")

    selected = category_map.get(category_key)
    if not selected:
        await callback.answer("Ошибка: неизвестная категория")
        return

    dishes = category_data[selected]
    await state.update_data(dishes=dishes, index=0)
    await send_dish_card(callback.message, callback.from_user.id, dishes[0], lang)

    await state.set_state(DishState.viewing)

async def send_dish_card(message: types.Message, user_id: int, dish, lang: str):
    name = dish["name_ru"] if lang == "ru" else dish["name_kz"]
    desc = dish["description_ru"] if lang == "ru" else dish["description_kz"]
    price = dish["price"]
    image_path = dish["image"]

    caption = f"<b>{name}</b>\n{desc}\n\n<b>Цена:</b> {price} ₸"

    builder = InlineKeyboardBuilder()
    builder.row(
        types.InlineKeyboardButton(text="➕ Добавить", callback_data=f"add_{dish['key']}"),
        types.InlineKeyboardButton(text="➡️ Следующее", callback_data="next_dish")
    )
    builder.row(
        types.InlineKeyboardButton(text="⬅️ Назад", callback_data="back_to_categories")
    )

    await message.answer_photo(
        photo=types.FSInputFile(image_path),
        caption=caption,
        reply_markup=builder.as_markup(),
        parse_mode="HTML"
    )

@router.callback_query(F.data == "back_to_categories")
async def back_to_categories(callback: types.CallbackQuery):
    from handlers.menu_categories import show_menu_categories
    await show_menu_categories(callback, None)