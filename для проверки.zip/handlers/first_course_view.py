from aiogram import Router, types, F
from aiogram.utils.markdown import hbold
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from aiogram.utils.keyboard import InlineKeyboardBuilder

from data.first_course import first_course_items

router = Router()

# Состояние FSM для ввода порций
class PortionState(StatesGroup):
    waiting_for_portion = State()

# Показывает карточку блюда
@router.callback_query(F.data.startswith("view_"))
async def show_dish(callback: types.CallbackQuery, state: FSMContext):
    dish_key = callback.data.split("_", 1)[1]
    dish = next((item for item in first_course_items if item["key"] == dish_key), None)

    if not dish:
        await callback.message.answer("Блюдо не найдено.")
        return

    await state.update_data(selected_dish=dish)

    text = (
        f"🍽 {hbold(dish['name_ru'])}\n"
        f"{dish['description_ru']}\n"
        f"💰 Цена: {dish['price']} тг"
    )

    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="➕ Добавить", callback_data="add_to_cart")],
        [InlineKeyboardButton(text="⬅️ Назад", callback_data="back_to_first_courses")]
    ])

    await callback.message.delete()
    await callback.message.answer_photo(
        photo=types.FSInputFile(dish["image"]),
        caption=text,
        reply_markup=keyboard,
        parse_mode="HTML"
    )

# Запрашиваем порцию
@router.callback_query(F.data == "add_to_cart")
async def ask_portion(callback: types.CallbackQuery, state: FSMContext):
    await callback.message.answer("🧮 Сколько порций вы хотите?")
    await state.set_state(PortionState.waiting_for_portion)

# Получаем порцию и сохраняем
@router.message(PortionState.waiting_for_portion)
async def save_portion(message: types.Message, state: FSMContext):
    if not message.text.isdigit():
        await message.answer("Пожалуйста, введите число.")
        return

    data = await state.get_data()
    dish = data.get("selected_dish")
    portion = int(message.text)

    from handlers.cart import add_to_cart
    await add_to_cart(user_id=message.from_user.id, dish=dish, portion=portion)

    text = (
        f"✅ Вы добавили:\n"
        f"🍽 {dish['name_ru']}\n"
        f"🔢 Кол-во: {portion} порций\n"
        f"💰 Цена за 1: {dish['price']} тг\n"
        f"💵 Общая сумма: {dish['price'] * portion} тг"
    )

    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🛒 Моя корзина", callback_data="show_cart")],
        [InlineKeyboardButton(text="⬅️ Назад", callback_data="back_to_first_courses")]
    ])

    await message.answer(text, reply_markup=keyboard)
    await state.clear()

# Обработка кнопки "⬅️ Назад" — возвращаем к списку первых блюд
# Обработка кнопки "⬅️ Назад" — возвращаем к списку первых блюд
@router.callback_query(F.data == "back_to_first_courses")
async def back_to_first_courses(callback: types.CallbackQuery):
    builder = InlineKeyboardBuilder()

    for item in first_course_items:
        builder.button(
            text=f"🍽 {item['name_ru']}",
            callback_data=f"view_{item['key']}"
        )
    builder.adjust(2)

    # Добавляем кнопку назад к категориям
    builder.row(
        types.InlineKeyboardButton(text="⬅️ Назад к категориям", callback_data="back_to_menu_categories")
    )

    await callback.message.delete()
    await callback.message.answer(
        "📋 Выберите блюдо из списка:",
        reply_markup=builder.as_markup()
    )