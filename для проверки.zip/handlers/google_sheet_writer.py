import gspread
import os
from dotenv import load_dotenv
from oauth2client.service_account import ServiceAccountCredentials

load_dotenv()

def save_booking(date, time, count, contact):
    scope = [
        "https://spreadsheets.google.com/feeds",
        "https://www.googleapis.com/auth/drive"
    ]

    key_path = os.getenv("GOOGLE_KEY_PATH")
    creds = ServiceAccountCredentials.from_json_keyfile_name(key_path, scope)
    client = gspread.authorize(creds)

    sheet = client.open_by_url("https://docs.google.com/spreadsheets/d/1ur9uxSVVt8b1ZaeBJ-Bkr1jQ2y_kYC6gtcaaMC13m8k/edit?usp=sharing").sheet1
    sheet.append_row([date, time, count, contact])