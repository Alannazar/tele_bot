# handlers/state.py

user_lang = {}