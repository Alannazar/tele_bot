dishes = [
    {
        "name_ru": "Шурпа",
        "name_kz": "Шурпа",
        "description_ru": "Классический наваристый суп с сочной говядиной и овощами.",
        "description_kz": "Сиыр еті мен көкөністер қосылған қою дәстүрлі сорпа.",
        "price": 1300,
        "image": "img/first/shurpa.jpg"
    },
    {
        "name_ru": "Мастава",
        "name_kz": "Мастава",
        "description_ru": "Ароматный рисовый суп с нутом и говядиной.",
        "description_kz": "Ноқат пен сиыр еті қосылған хош иісті күріш сорпасы.",
        "price": 1000,
        "image": "img/first/mastava.jpg"
    },
    {
        "name_ru": "Кюфта",
        "name_kz": "Кюфта",
        "description_ru": "Традиционный суп с мясными шариками, нутом и картофелем.",
        "description_kz": "Ет шариктері, ноқат пен картоп қосылған дәстүрлі сорпа.",
        "price": 1200,
        "image": "img/first/kufta.jpg"
    },
    {
        "name_ru": "Лапша по-домашнему",
        "name_kz": "Үй кеспесі",
        "description_ru": "Домашняя лапша с курицей в ароматном бульоне.",
        "description_kz": "Тауық етімен хош иісті сорпада пісірілген үй кеспесі.",
        "price": 1400,
        "image": "img/first/lapsha.jpg"
    },
    {
        "name_ru": "Фрикадельковый суп",
        "name_kz": "Фрикаделька сорпасы",
        "description_ru": "Лёгкий суп с домашними фрикадельками.",
        "description_kz": "Үй фрикаделькалары қосылған жеңіл сорпа.",
        "price": 1200,
        "image": "img/first/frikadel.jpg"
    },
    {
        "name_ru": "Куза шурпа",
        "name_kz": "Қуза шурпа",
        "description_ru": "Суп с тушёной говядиной, нутом и картофелем.",
        "description_kz": "Бұқтырылған сиыр еті, ноқат және картоп қосылған сорпа.",
        "price": 1500,
        "image": "img/first/kuza_shurpa.jpg"
    },
]