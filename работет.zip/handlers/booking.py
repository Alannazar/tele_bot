from aiogram import Router, types
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.context import FSMContext
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from handlers.state import user_lang
from handlers.google_sheet_writer import save_booking  # добавлено

router = Router()

class BookingState(StatesGroup):
    waiting_for_people = State()
    waiting_for_date = State()
    waiting_for_time = State()
    waiting_for_name = State()

@router.callback_query(lambda c: c.data == "booking")
async def start_booking(callback: types.CallbackQuery, state: FSMContext):
    lang = user_lang.get(callback.from_user.id, "ru")
    if lang == "kz":
        await callback.message.answer("👥 Қанша адамға бронь жасағыңыз келеді?")
    else:
        await callback.message.answer("👥 Сколько человек вы хотите забронировать?")
    await state.set_state(BookingState.waiting_for_people)

@router.message(BookingState.waiting_for_people)
async def get_people(message: types.Message, state: FSMContext):
    await state.update_data(people=message.text)
    lang = user_lang.get(message.from_user.id, "ru")
    if lang == "kz":
        await message.answer("📅 Қай күнге бронь жасайсыз?")
    else:
        await message.answer("📅 На какую дату вы хотите сделать бронирование?")
    await state.set_state(BookingState.waiting_for_date)

@router.message(BookingState.waiting_for_date)
async def get_date(message: types.Message, state: FSMContext):
    await state.update_data(date=message.text)
    lang = user_lang.get(message.from_user.id, "ru")
    if lang == "kz":
        await message.answer("⏰ Қай уақытқа?")
    else:
        await message.answer("⏰ На какое время?")
    await state.set_state(BookingState.waiting_for_time)

@router.message(BookingState.waiting_for_time)
async def get_time(message: types.Message, state: FSMContext):
    await state.update_data(time=message.text)
    lang = user_lang.get(message.from_user.id, "ru")
    if lang == "kz":
        await message.answer("👤 Атыңыз бен телефон нөміріңізді жазыңыз:")
    else:
        await message.answer("👤 Пожалуйста, напишите ваше имя и номер телефона:")
    await state.set_state(BookingState.waiting_for_name)

@router.message(BookingState.waiting_for_name)
async def get_name(message: types.Message, state: FSMContext):
    await state.update_data(name=message.text)
    data = await state.get_data()
    lang = user_lang.get(message.from_user.id, "ru")

    # Сохраняем данные в Google Таблицу
    save_booking(data['date'], data['time'], data['people'], data['name'])

    if lang == "kz":
        text = (
            "✅ <b>Сіздің брондауыңыз:</b>\n"
            f"👥 Адам саны: {data['people']}\n"
            f"📅 Күні: {data['date']}\n"
            f"⏰ Уақыты: {data['time']}\n"
            f"👤 Байланыс: {data['name']}\n\n"
            "🍽️ Енді мәзірден тағам таңдаңыз!"
        )
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="📋 Мәзір", callback_data="menu")],
            [
                InlineKeyboardButton(text="WhatsApp", url="https://wa.me/77001234567"),
                InlineKeyboardButton(text="Instagram", url="https://instagram.com/yourpage")
            ]
        ])
    else:
        text = (
            "✅ <b>Ваше бронирование:</b>\n"
            f"👥 Кол-во: {data['people']}\n"
            f"📅 Дата: {data['date']}\n"
            f"⏰ Время: {data['time']}\n"
            f"👤 Контакт: {data['name']}\n\n"
            "🍽️ Теперь выберите блюдо из меню!"
        )
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="📋 Меню", callback_data="menu")],
            [
                InlineKeyboardButton(text="WhatsApp", url="https://wa.me/77001234567"),
                InlineKeyboardButton(text="Instagram", url="https://instagram.com/yourpage")
            ]
        ])

    await message.answer(text, reply_markup=keyboard, parse_mode="HTML")
    await state.clear()