from aiogram import Router, types
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

router = Router()

# Хранилище корзины (в памяти)
user_cart = {}

async def add_to_cart(user_id: int, dish: dict, portion: int):
    if user_id not in user_cart:
        user_cart[user_id] = []
    user_cart[user_id].append({
        "name": dish["name_ru"],
        "price": dish["price"],
        "portion": portion
    })

@router.callback_query(lambda c: c.data == "show_cart")
async def show_cart(callback: types.CallbackQuery):
    cart = user_cart.get(callback.from_user.id, [])
    if not cart:
        await callback.message.answer("🛒 Ваша корзина пуста.")
        return

    text = "🛒 <b>Ваша корзина:</b>\n\n"
    total = 0
    for item in cart:
        subtotal = item["price"] * item["portion"]
        total += subtotal
        text += (
            f"🍽 {item['name']} — {item['portion']} шт. × {item['price']} = {subtotal} тг\n"
        )
    text += f"\n💵 <b>Итого: {total} тг</b>"

    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⬅️ Назад", callback_data="back_to_first_courses")]
    ])

    await callback.message.answer(text, reply_markup=keyboard, parse_mode="HTML")