from aiogram import Router, types
from aiogram.utils.keyboard import InlineKeyboardBuilder
from handlers.language import user_lang
from handlers.menu import show_welcome_menu

router = Router()

@router.callback_query(lambda c: c.data == "menu")
async def show_menu_categories(callback: types.CallbackQuery):
    lang = user_lang.get(callback.from_user.id, "ru")
    builder = InlineKeyboardBuilder()

    if lang == "kz":
        builder.row(
            types.InlineKeyboardButton(text="🥣 1-ші тағам", callback_data="category_1"),
            types.InlineKeyboardButton(text="🥗 Салаттар", callback_data="category_4"),
            types.InlineKeyboardButton(text="🥟 Тапсымалар", callback_data="category_6")
        )
        builder.row(
            types.InlineKeyboardButton(text="🍛 2-ші тағам", callback_data="category_2"),
            types.InlineKeyboardButton(text="🍖 Шашлықтар", callback_data="category_3"),
            types.InlineKeyboardButton(text="🥤 Сусындар", callback_data="category_5")
        )
        builder.row(
            types.InlineKeyboardButton(text="🟢 Байланыс", callback_data="contact")
        )
        builder.row(
            types.InlineKeyboardButton(text="↩️ Артқа", callback_data="back_to_main")
        )
        text = (
            "<b>Мәзір бөлімін таңдаңыз:</b>\n"
            "🍽️ <i>Біздің ең дәмді тағамдарымызды таңдаңыз.</i>\n\n"
            "⬇️ Қалаған санатты таңдаңыз:"
        )
    else:
        builder.row(
            types.InlineKeyboardButton(text="🥣 1-е блюдо", callback_data="category_1"),
            types.InlineKeyboardButton(text="🥗 Салаты", callback_data="category_4"),
            types.InlineKeyboardButton(text="🥟 Выпечка", callback_data="category_6")
        )
        builder.row(
            types.InlineKeyboardButton(text="🍛 2-е блюдо", callback_data="category_2"),
            types.InlineKeyboardButton(text="🍖 Шашлыки", callback_data="category_3"),
            types.InlineKeyboardButton(text="🥤 Напитки", callback_data="category_5")
        )
        builder.row(
            types.InlineKeyboardButton(text="🟢 Контакты", callback_data="contact")
        )
        builder.row(
            types.InlineKeyboardButton(text="↩️ Назад", callback_data="back_to_main")
        )
        text = (
            "<b>Выберите категорию меню:</b>\n"
            "🍽️ <i>Самые вкусные блюда только у нас!</i>\n\n"
            "⬇️ Выберите категорию:"
        )

    await callback.message.delete()
    await callback.message.answer(
        text,
        reply_markup=builder.as_markup(),
        parse_mode="HTML"
    )

@router.callback_query(lambda c: c.data == "back_to_main")
async def back_to_main_from_categories(callback: types.CallbackQuery):
    lang = user_lang.get(callback.from_user.id, "ru")
    await callback.message.delete()
    await show_welcome_menu(callback, lang)

# ДОБАВЛЕННОЕ: Возврат к меню категорий
@router.callback_query(lambda c: c.data == "back_to_menu_categories")
async def back_to_menu_categories(callback: types.CallbackQuery):
    await show_menu_categories(callback)